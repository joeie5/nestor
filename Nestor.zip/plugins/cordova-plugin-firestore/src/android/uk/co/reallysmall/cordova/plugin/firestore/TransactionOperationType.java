package uk.co.reallysmall.cordova.plugin.firestore;

enum TransactionOperationType {
    NONE,
    SET,
    UPDATE,
    DELETE,
    RESOLVE
}
