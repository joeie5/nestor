function check_info(){
    var username = document.getElementById('username').value;
    var username = document.getElementById('email').value;
    var username = document.getElementById('password').value;
    var username = document.getElementById('repassword').value;
    var username = document.getElementById('repassword').value;
}   

if (username=="") {
    alert('Please Enter your username')
} else {
    return true;
}